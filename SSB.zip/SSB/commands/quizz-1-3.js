const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    
    let quizzoneaswerthree = new Discord.RichEmbed()
.setColor(client.color)
.setAuthor(msg.author.tag, msg.author.avatarURL)
.addField('Antwort 3 ist...', '**__FALSCH__**')

let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

let testEmbed = new Discord.RichEmbed()
.setAuthor(msg.author.tag, msg.author.avatarURL)
.setColor(client.color)
.addField("Server:", `**${msg.guild.name}**`)
.addField("User:", `**${msg.author.tag}**`)
.addField("Benutzter Command:", "**quizz-1-3**")

bugreporthook.send(testEmbed)
msg.channel.send(quizzoneaswerthree)

}

module.exports.help = {
name: "quizz-1-3"

}