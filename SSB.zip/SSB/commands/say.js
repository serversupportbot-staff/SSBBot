const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    if(!args) {

        msg.channel.send(' :error: | Also, also. Ich kann doch keine Leeren Nachrichten Senden!')

    } else {
        msg.delete()
       
        let sayembed = new Discord.RichEmbed()
        .setColor(client.color)
        .setTitle(args.join(' '))
        .setFooter(`Requested by ${msg.author.tag}`)

        let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

        let testEmbed = new Discord.RichEmbed()
        .setAuthor(msg.author.tag, msg.author.avatarURL)
        .setColor(client.color)
        .addField("Server:", `**${msg.guild.name}**`)
        .addField("User:", `**${msg.author.tag}**`)
        .addField("Benutzter Command:", "**say**")
        .addField("Text:", args.join(' '))
       
        bugreporthook.send(testEmbed)
        
        msg.channel.send(sayembed)

    }

}

module.exports.help = {
    name: "say"
}