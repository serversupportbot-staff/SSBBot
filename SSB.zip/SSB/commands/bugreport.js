const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    if(!args) {

        msg.channel.send(' :error: | Also, also. Ich kann doch keinen Leeren Bugreport senden Senden!')

    } else {
        msg.delete()
       
       let bugreporthook = new Discord.WebhookClient('557577467158855691', 'ZhlLbrEB47aW-Uq9X1zcpEGFON4PukW21__iPrMnpWI-9gnY4vx4x40fFGio6mTmq974')

let testEmbed = new Discord.RichEmbed()
.setAuthor(msg.author.tag, msg.author.avatarURL)
.setColor(client.color)
.setDescription(args.join(' '))

let hook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

let Embed = new Discord.RichEmbed()
.setAuthor(msg.author.tag, msg.author.avatarURL)
.setColor(client.color)
.addField("Server:", `**${msg.guild.name}**`)
.addField("User:", `**${msg.author.tag}**`)
.addField("Benutzter Command:", "**bugreport**")
.addField("Bug", args.join(' '))

hook.send(Embed)

return bugreporthook.send(testEmbed)

    }

}

module.exports.help = {
    name: "bugreport"
}