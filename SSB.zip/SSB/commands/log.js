const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

 let logembed = new Discord.RichEmbed()
 .setColor(client.color)
 .setFooter("INFO: Um den Log zu deaktivieren musst du nur den Channel löschen")
 .setTitle("Log")
 .setDescription("Um den Log zu **Aktivieren** musst du einen channel names ``log`` erstellen")

 let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

let testEmbed = new Discord.RichEmbed()
.setAuthor(msg.author.tag, msg.author.avatarURL)
.setColor(client.color)
.addField("Server:", `**${msg.guild.name}**`)
.addField("User:", `**${msg.author.tag}**`)
.addField("Benutzter Command:", "**log**")

bugreporthook.send(testEmbed)

 msg.channel.send(logembed)

}

module.exports.help = {
    name: "log"
    
    }