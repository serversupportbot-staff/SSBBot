const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    
    let helpembed = new Discord.RichEmbed()
.setColor(client.color)
.setAuthor(msg.author.tag, msg.author.avatarURL)
.addField('Partnerbot-Liste:', 'Nagisa \nKeksBot')
.addField('Wie wird mein Bot partnerbot ?', 'Komme einfach auf den Support Server und frage einen Developer')
.addField('Nagisa', '**[Invite](https://discordapp.com/oauth2/authorize?client_id=550349960160477199&permissions=8&scope=bot)**')
.addField('KeksBot', '**[Invite](https://discordapp.com/oauth2/authorize?client_id=493066387183632387&scope=bot&permissions=1322054)**')

let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

let testEmbed = new Discord.RichEmbed()
.setAuthor(msg.author.tag, msg.author.avatarURL)
.setColor(client.color)
.addField("Server:", `**${msg.guild.name}**`)
.addField("User:", `**${msg.author.tag}**`)
.addField("Benutzter Command:", "**partnerbots**")

bugreporthook.send(testEmbed)
msg.channel.send(helpembed)

}

module.exports.help = {
name: "partnerbot"

}