const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    let guildnummer = client.guilds.size
    let membernummer = client.users.size
    let helpembed = new Discord.RichEmbed()
    .setColor(client.color)
    .setAuthor(msg.author.tag, msg.author.avatarURL)
    .addField('**__ABOUT THE SUPPORT SERVER__**', '**_____________**')
    .addField('__SSB Staffs__', "**Maurice-Pascal, Spirit, Lukas Thurnes**")
    .addField('__Server Personal__', "**DiraxLP, Keks Ofs | Sebl, Sweat  Smile, Lukas Thurnes, Maurice-Pascal, Spirit**")
    .addField('__Adminstartors__', "**lascap-eciruam, Maurice-Pascal, Spirit, Lukas Thurnes**")
    .addField('__Moderators__', "**DiraxLP, Keks Ofs | Sebl**")
    .addField('__Supporter__', '**DiraxLP, Sweat  Smile, Keks Ofs | Sebl**')
    .addField('__Donators__', '**Keine**')
    .addField('__* Rechte__', '**lascap-eciruam, Lukas Thurnes, Maurice-Pascal, Spirit**')

    let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

    let testEmbed = new Discord.RichEmbed()
    .setAuthor(msg.author.tag, msg.author.avatarURL)
    .setColor(client.color)
    .addField("Server:", `**${msg.guild.name}**`)
    .addField("User:", `**${msg.author.tag}**`)
    .addField("Benutzter Command:", "**about-support**")
   
    bugreporthook.send(testEmbed)
    msg.channel.send(helpembed)

}

module.exports.help = {
    name: "about-support"
}