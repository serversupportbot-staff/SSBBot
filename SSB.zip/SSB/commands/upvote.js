const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    let umfrageArgs = args.join(' ')

    if(!args) {

        msg.channel.send(' :error: | Also, also. Ich kann doch keine Leeren Nachrichten Senden!')

    } else if(msg.author.id === '477599429486968862') {
        msg.delete()
        
        
        let voteembed = new Discord.RichEmbed()

        .setColor(client.color)
        .setTitle("Upvote-Suggestion")
        .setDescription(`${umfrageArgs}`)
        .setFooter("👍 Like it | 👎 Like it not")
    
    
        
        msg.channel.send(voteembed)
            .then(function (msg) {
          msg.react("👍")
          msg.react("👎")
         });
        }        
}

module.exports.help = {
    name: "upvote"
}