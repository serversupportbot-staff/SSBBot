const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    
    let helpembed = new Discord.RichEmbed()
 .setColor(client.color)
 .setAuthor(msg.author.tag, msg.author.avatarURL)
 .setDescription('**__Command-Übersicht__** \n\n**:gear: • Nützliches <:emoji_2:552959848288092160>** \n``avatar``, ``vote``, ``Nintendo-News``, ``Serverinfo``, ``Userinfo`` \n\n**📝 • Serververwaltung <:emoji_4:556619556932550656>** \n``Kick``, ``Ban``, ``report``, ``mute``, ``clear`` \n\n**🍪 • Fun <:emoji_2:552959848288092160>** \n``say``, ``randomnumber``, ``ask`` \n\n**<:emoji_1:552856301831454720> • Bot <:emoji_2:552959848288092160>** \n``ping``, ``invite``, ``support``, ``about``, ``partnerbot``, ``botvote``, ``Bot-News``, ``Forum``, ``Bugreport``, ``Vorschlag``, ``Quizz-suggestion``, ``Quizz``, ``about-support`` \n\n**:underage: • NSFW <:emoji_4:556619556932550656>** **___(BETA)___**\n``boobs``\n\n**Infos:** \nMit ssb!help-<command> erhälst du infos über den command. \n\n**Modul mit <:emoji_2:552959848288092160>** \nBedeutet das das modul verfügbar ist \n\n**Modul mit <:emoji_4:556619556932550656>** \nBedeutet das das Modul nur halbwegs funktioniert \n\n**Modul mit <:emoji_3:552959885428391971>** \nBedeutet das das modul nicht verfügbar ist \n\n**:paperclip: • Links** \n**[Support Server](https://discordapp.com/invite/RKr6BQ8)** | **[Invite](https://discordapp.com/api/oauth2/authorize?client_id=552236054506373146&permissions=8&scope=bot)** | **[Vote](https://discordbots.org/bot/552236054506373146/vote)**')
 .setFooter(`Insgesamt regestrierte commands: ${client.commands.size}`)
 .setTimestamp(new Date())

 let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

 let testEmbed = new Discord.RichEmbed()
 .setAuthor(msg.author.tag, msg.author.avatarURL)
 .setColor(client.color)
 .addField("Server:", `**${msg.guild.name}**`)
 .addField("User:", `**${msg.author.tag}**`)
 .addField("Benutzter Command:", "**help**")

 bugreporthook.send(testEmbed)
 msg.channel.send(helpembed)

}

module.exports.help = {
name: "help"

}