const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    let kUser = msg.guild.member(msg.mentions.users.first() || msg.guild.members.get(args[0]))
    if(!kUser) return msg.channel.send("User nicht gefunden/Bitte Tagge einen User!")
    let kReason = args.join(" ").slice(22)
    if(!kReason) return msg.channel.send("Du benötigst einen grund um jemanden zu Reporten")

    let kickEmbed = new Discord.RichEmbed()
    .setColor("#df1717")
    .addField("Reporteter User", `| ${kUser} \n| ID ${kUser.id}`)
    .addField("Grund", `| ${kReason}`)
    .addField("Reportet von", `| <@${msg.author.id}> \n| ID ${msg.author.id}`)
    .addField("Channel", `| ${msg.channel}`)
    .addField("Datum", `| ${msg.createdAt}`)

    let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

    let testEmbed = new Discord.RichEmbed()
    .setAuthor(msg.author.tag, msg.author.avatarURL)
    .setColor(client.color)
    .addField("Server:", `**${msg.guild.name}**`)
    .addField("User:", `**${msg.author.tag}**`)
    .addField("Benutzter Command:", "**report**")
    .addField("Reporteter User:", `${kUser}`)
    .addField("Grund:", `${kReason}`)
   
    bugreporthook.send(testEmbed)

    let lal = new Discord.RichEmbed()
    .setColor(client.color)
    .setDescription(`Du hast erfolgreich ${kUser.tag} auf ${msg.guild.name} reportet wegen: ``${kReason}```)
    .setFooter(`Das Serverteam von ${msg.guild.name} hat den Report empfangen`)

    let kickChannel = msg.guild.channels.find(`name`, "reports")
    if(!kickChannel) return msg.channel.send("Es muss zuerst der Channel `reprts` erstellt werden, bevor du jemanden reporten kannst")

    kickChannel.send(kickEmbed)
    kUser.send(lal)

    return
}

module.exports.help = {
    name: "report"
    
    }