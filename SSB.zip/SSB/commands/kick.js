const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    let kUser = msg.guild.member(msg.mentions.users.first() || msg.guild.members.get(args[0]))
    if(!kUser) return msg.channel.send("User nicht gefunden/Bitte Tagge einen User!")
    let kReason = args.join(" ").slice(22)
    if(!msg.member.hasPermission("KICK_MEMBERS", "ADMINSTRATOR")) return msg.channel.send("Du hast nicht die nötigen berechtigungen. Du benötigst: ``KICK_MEMBERS`` oder ``ADMINSTRATOR``")
    if(kUser.hasPermission("KICK_MEMBERS", "ADMINSTRATOR", "BAN_MEMBERS", "MANAGE_SERVER")) return msg.channel.send("Du kannst keine Moderatoren/Admins Kick")
    if(!kReason) return msg.channel.send("Du benötigst einen grund um jemanden zu Kicken")

    kUser.send(`Hoppla, du wurdest von **${msg.guild.name}** gekickt aufgrund von: **${kReason}**`)

    let kickEmbed = new Discord.RichEmbed()
    .setTitle("")
    .setColor("#df1717")
    .addField("Gekickter User", `${kUser} \n| ID ${kUser.id}`)
    .addField("Grund", kReason)
    .addField("Moderator", `<@${msg.author.id}> \n| ID ${msg.author.id}`)
    .addField("Channel", msg.channel)
    .addField("Datum", msg.createdAt)

    let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

    let testEmbed = new Discord.RichEmbed()
    .setAuthor(msg.author.tag, msg.author.avatarURL)
    .setColor(client.color)
    .addField("Server:", `**${msg.guild.name}**`)
    .addField("User:", `**${msg.author.tag}**`)
    .addField("Benutzter Command:", "**kick**")
    .addField("Gekickter User:", `${kUser}`)
   
    bugreporthook.send(testEmbed)

    let kickChannel = msg.guild.channels.find(`name`, "modlogs")
    if(!kickChannel) return msg.channel.send("Ich konnte keinen channel mit dem namen ``modlog`` finden. Erstelle diesen channel um diesen command nutzen zu können")

    msg.guild.member(kUser).kick(kReason)
    kickChannel.send(kickEmbed)
    msg.channel.send(`Du hast ${kUser} erfolgreich wegen ${kReason} gekickt`)

    return
}

module.exports.help = {
    name: "kick"
    
    }