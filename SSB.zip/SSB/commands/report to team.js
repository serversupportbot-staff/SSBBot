const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    let kReason = args.join(" ")
    if(!kReason) return msg.channel.send("Du benötigst einen grund um etwas an das Server Team zu melden")

    let kickEmbed = new Discord.RichEmbed()
    .setColor("#df1717")
    .addField("Gemeldet von", `| ${msg.author.tag} \n| ID ${msg.author.id}`)
    .addField("Was gemeldet wurde", `| ${kReason}`)
    .addField("Channel", `| ${msg.channel}`)
    .addField("Datum", `| ${msg.createdAt}`)

    let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

    let testEmbed = new Discord.RichEmbed()
    .setAuthor(msg.author.tag, msg.author.avatarURL)
    .setColor(client.color)
    .addField("Server:", `**${msg.guild.name}**`)
    .addField("User:", `**${msg.author.tag}**`)
    .addField("Benutzter Command:", "**report**")
    .addField("Grund:", `${kReason}`)
   
    bugreporthook.send(testEmbed)

    let kickChannel = msg.guild.channels.find(`name`, "reports-to-team")
    if(!kickChannel) return msg.channel.send("Es muss zuerst der Channel `reports-to-team` erstellt werden, bevor du jemanden reporten kannst")

    kickChannel.send(kickEmbed)
    msg.channel.send(`<@${msg.author.id}> hat erfolgreich etwas dem Server Team gemeldet`)

    return
}

module.exports.help = {
    name: "report-to-team"
    
    }