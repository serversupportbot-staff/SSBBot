const Discord = require('discord.js')

module.exports.run = async (client, msg, args) => {

    let serverinfo = new Discord.RichEmbed()
    .setTitle(`Serverinfo von ${msg.guild.name}`)
    .setColor(client.color)
    .addField("**__Name:__**:", `**${msg.guild.name}**`, true)
    .addField("**__Server Besitzer:__**", `**${msg.guild.owner.user.tag}**`, true)
    .addField("**__Erstellt am:__**", `**${msg.guild.createdAt}**`, true)
    .addField("**__Member:__**", `**${msg.guild.memberCount}**`, true)
    .setThumbnail(msg.guild.iconURL)

    let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

        let testEmbed = new Discord.RichEmbed()
        .setAuthor(msg.author.tag, msg.author.avatarURL)
        .setColor(client.color)
        .addField("Server:", `**${msg.guild.name}**`)
        .addField("User:", `**${msg.author.tag}**`)
        .addField("Benutzter Command:", "**serverinfo**")
       
        bugreporthook.send(testEmbed)
    
    msg.channel.send(serverinfo)
}

module.exports.help = {
    name: "serverinfo"
}