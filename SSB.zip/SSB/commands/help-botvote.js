const Discord = require("discord.js")

module.exports.run = async (client, msg, args) => {

    
    let helpembed = new Discord.RichEmbed()
.setColor(client.color)
.setAuthor(msg.author.tag, msg.author.avatarURL)
.addField('**__Command-Info zu:__** ssb!botvote', 'Mit ssb!botvote schickt dir <@552236054506373146> ein Link zur Discord Botlist Webseite. Dort kannst du für den bot Voten <3')

let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

let testEmbed = new Discord.RichEmbed()
.setAuthor(msg.author.tag, msg.author.avatarURL)
.setColor(client.color)
.addField("Server:", `**${msg.guild.name}**`)
.addField("User:", `**${msg.author.tag}**`)
.addField("Benutzter Command:", "**help-botvote**")

bugreporthook.send(testEmbed)
msg.channel.send(helpembed)

}

module.exports.help = {
name: "help-botvote"

}