const Discord = require("discord.js");
const moment = require("moment")

module.exports.run = async (client, msg, args) => {
    let user;
    if (msg.mentions.users.first()) {
        user = msg.mentions.users.first();
    } else {
        user = msg.author;
    }

    const member = msg.guild.member(user);

    const embed = new Discord.RichEmbed()
    .setColor("RANDOM")
    .setThumbnail(msg.author.avatarURL)
    .setTitle(`${user.tag}`)
    .addField("Nickname", `${member.nickname !== null ? `${member.nickname}` : 'None'}`, true)
    .addField("Erstellt am", `${moment.utc(member.joinedAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true)
    .addField("Bot", `${user.bot}`, true)
    .addField("Status", `${user.presence.status}`, true)
    .addField("Game", `${user.presence.game ? user.presence.game.name : 'None'}`, true)
    .addField("Roles", member.roles.map(roles => `${roles.name}`).join(', '), true)

    let bugreporthook = new Discord.WebhookClient('566340990944804884', 'MZst0pwW00ws55uOLyzDmf-76MwwQ3Ls3BxR_6bxa6ZFd9ecG_o34Ym9npJ5LdpTwb2g')

        let testEmbed = new Discord.RichEmbed()
        .setAuthor(msg.author.tag, msg.author.avatarURL)
        .setColor(client.color)
        .addField("Server:", `**${msg.guild.name}**`)
        .addField("User:", `**${msg.author.tag}**`)
        .addField("Benutzter Command:", "**userinfo**")
        .addField("Über:", `${user}`)
       
        bugreporthook.send(testEmbed)

    msg.channel.send({embed})

}

module.exports.help = {
    name: "userinfo"
    
}